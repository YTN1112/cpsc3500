#include <fstream>
#include <iostream>
#include <iomanip>
#include <list>
#include <queue>
#include <vector>
#include <algorithm>
#include <cstring>

using namespace std;


// This function determines if we need to swap the two based on the arrivial time

struct Process {
    int ID;
    int ArriveTime;
    int BurstTime;
    int remainingTime;
    int waitingTime;
    bool running;
};

bool compareArriveTime(const Process* swapA, const Process* swapB);

bool compareID(const Process* swapA, const Process* swapB);

int FSFSProcess(vector <Process *> list);


int main(int argc, char *argv[]){
    if (argc != 3 && argc != 4){
        cout << "ERROR WITH COMMAND LINE." << endl;
        return 0;
    }
    if (argc == 3){
        if (strcmp(argv[2], "FCFS") != 0 && strcmp(argv[2], "SRT") != 0){
            cout << "ERROR WITH COMMAND LINE." << endl;
            return 0;
        }
    }
    if (argc == 4){
        if (strcmp(argv[2], "RR") != 0){
            cout << "ERROR WITH COMMAND LINE." << endl;
            return 0;
        }
        if (atoi(argv[3]) <= 0){
            cout << "ERROR WITH COMMAND LINE." << endl;
            return 0;
        }
    }
    ifstream file(argv[1]);  
    if (file.fail()){
        cout << "INVALID FILE!" << endl;
        return 0;
    }
    string line;
    vector<Process *> processList;
    cout << "CHECK HERE!" << endl;
    while (getline(file,line)){
    // fileread
        stringstream s = stringstream(line);
        string IDinput;
        string ArriveTimeInput;
        string BurstTimeInput;
        getline(s, IDinput, ' ');    // Read the date column
        getline(s, ArriveTimeInput, ' '); // Read the country column
        getline(s, BurstTimeInput, ' ');   // Read the cases column
        int IDint = stoi(IDinput);
        int ArriveTimeInt = stoi(ArriveTimeInput);
        int BurstTimeInt = stoi(BurstTimeInput);
        Process * create = new Process();
        create->ID = IDint;
        create->ArriveTime = ArriveTimeInt;
        create->BurstTime = BurstTimeInt;
        create->remainingTime = create->ArriveTime;
        create->waitingTime = 0;
        processList.push_back(create);

        }
    file.close();
    sort(processList.begin(), processList.end(),compareArriveTime);
    //FSFSProcess(processList);
    for (int i = 0; i < (int)processList.size(); i++){
        cout << processList[i]->ID;
        cout << processList[I]->
    }


    return 0;
}
// Should I sort by ID or arrival time?

bool compareArriveTime(const Process* swapA, const Process* swapB){
    return swapA->ArriveTime < swapB->ArriveTime;
}

int FSFSProcess(vector <Process *> list){
    queue <Process *> readyList;
    queue <Process *> waitingList;
    vector <Process *> tiedProcess;
    vector <Process *> terminatedProcesses;
    Process * startToRun;
    bool occupied = false;
    cout << "CHECK" << endl;
    for (int i = 0; i < (int)list.size(); i++){
        waitingList.push(list[i]);
    }
    int timeCount = 0;
    int idleTime = 0;
    while (!readyList.empty() || !waitingList.empty() || occupied){
        cout << timeCount << endl;
        if (readyList.empty() && !occupied && !waitingList.empty()){
            Process * waitingListFront = waitingList.front();
            cout << timeCount << endl;
            if (waitingListFront->ArriveTime == timeCount){
                while (waitingListFront->ArriveTime == timeCount){
                    cout << "HELLO1234" << endl;
                    tiedProcess.push_back(waitingListFront);
                    waitingList.pop();
                    waitingListFront = waitingList.front();
                    cout << timeCount << endl;
                }
                if (tiedProcess.size() != 1){
                    sort(tiedProcess.begin(),tiedProcess.end(),compareID);
                    for (int i = 0; i < (int)tiedProcess.size(); i++){
                        readyList.push(tiedProcess[i]);
                    }

                }
                startToRun = readyList.front();
                readyList.pop();
                occupied = true;

            }else{
                 idleTime++;
                 timeCount++;
            }

    }if (occupied){
        cout << "In start of occupred" << endl;
        if (startToRun->ArriveTime + startToRun->BurstTime == timeCount){
            Process * waitingListFront = waitingList.front();
            terminatedProcesses.push_back(startToRun);
            occupied = false;
            cout << "check.2" << endl;
            readyList.pop();
            if (!readyList.empty()){
                startToRun = readyList.front();
                occupied = true;
            }
            if (!waitingList.empty() && waitingListFront->ArriveTime == timeCount){
                while (waitingListFront->ArriveTime == timeCount){
                    tiedProcess.push_back(waitingListFront);
                    waitingList.pop();
                    waitingListFront = waitingList.front();
                }
                if (tiedProcess.size() != 1){
                    sort(tiedProcess.begin(),tiedProcess.end(),compareID);
                    for (int i = 0; i < (int)tiedProcess.size(); i++){
                        readyList.push(tiedProcess[i]);
                    }

                }
                startToRun = readyList.front();
                readyList.pop();
                occupied = true;
            }
        }
        cout << "check.3" << endl;
        if (!readyList.empty()){
            queue <Process *> tempQueue;
            cout << "check.4" << endl;
            bool frontNotNull = true;
            while (!readyList.empty() && frontNotNull){
                Process * front = readyList.front();
                    if (front != nullptr) {
                        readyList.pop();
                        cout << "check.5" << endl;
                        cout << "check.55" << endl;
                        front->waitingTime++;
                        tempQueue.push(front);
                }else{
                    frontNotNull = false;
                }
            }

            while (!tempQueue.empty()){
                cout << "check.6" << endl;
                Process * backIn = tempQueue.front();
                tempQueue.pop();
                if (backIn != nullptr){
                    readyList.push(backIn);
                }
            }
        }
        
    }
    timeCount++;
    cout << timeCount << endl;

}
    return 0;
}


bool compareID(const Process* swapA, const Process* swapB){
    return swapA->ID < swapB->ID;
}


vector<Process*> RRProcess(const vector<Process*>& list,int &totalTime, int &totalWaitingTime,int interval){
    queue <Process *> readyList;
    queue <Process *> waitingList;
    vector <Process *> tiedProcess;
    vector <Process *> terminatedProcesses;
    Process * startToRun;
    bool wasIdle;
    bool occupied = false;
    int intervalTimeLeft = interval;
    for (int i = 0; i < (int)list.size(); i++){
        waitingList.push(list[i]);
    }
    int timeCount = 0;
    int idleTime = 0;
    while (!readyList.empty() || !waitingList.empty() || occupied){
        if (!occupied){
            if (!readyList.empty()){
                startToRun = readyList.front();
                readyList.pop();
                occupied = true;
                cout << "Process " << startToRun->ID  << " running at time" << timeCount << endl;
                if (!readyList.empty()){
                    int readyListSize = readyList.size();
                    for (int i = 0; i < readyListSize; i++){
                        Process * front = readyList.front();
                        readyList.pop();
                        front->waitingTime++;
                        readyList.push(front);
                    }
                    while (waitingList.front() != nullptr && waitingList.front()->arriveTime == timeCount){
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push(front);
                    }
                }
            }else{
                if(waitingList.front()->arriveTime != timeCount){
                    idleTime++;
                    wasIdle = true;
                }else{
                    while (waitingList.front() != nullptr && waitingList.front()->arriveTime == timeCount){
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push(front);
                    }
                    if (!readyList.empty()){
                        startToRun = readyList.front();
                        readyList.pop();
                        cout << "Process " << startToRun->ID  << " running at time" << timeCount << endl;
                        occupied = true;
                        intervalTimeLeft = interval;
                    }else if(waitingList.empty() && !readyList.empty()){
                        cout << "CPU IDLE at time" << timeCount << endl;
                        idleTime++;
                        intervalTimeLeft = 0;
                    }
                    if(wasIdle){
                        idleTime++;
                        wasIdle = false;
                    }
                }
            }          
        }else{
            if (startToRun->remainingTime == 0){
                terminatedProcesses.push_back(startToRun);
                occupied = false;
                if (!readyList.empty()){
                    startToRun = readyList.front();
                    readyList.pop();
                    cout << "Process " << startToRun->ID  << " running at time" << timeCount << endl;
                    occupied = true;
                    intervalTimeLeft = interval;
                }if (readyList.empty() && !waitingList.empty() && waitingList.front()->arriveTime == timeCount){
                    while (waitingList.front() != nullptr && waitingList.front()->arriveTime == timeCount){
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push(front);
                    }
                    if (!readyList.empty()){
                        startToRun = readyList.front();
                        readyList.pop();
                        cout << "Process " << startToRun->ID  << " running at time" << timeCount << endl;
                        occupied = true;
                    }
                    if (wasIdle){
                        idleTime++;
                        wasIdle = false;
                    }
                    if (!readyList.empty()){
                        int readyListSize = readyList.size();
                        for (int i = 0; i < readyListSize;i++){
                        Process * front = readyList.front();
                        readyList.pop();
                        front->waitingTime++;
                        readyList.push(front);
                    }

                }
                }else if(readyList.empty() && !waitingList.empty() && waitingList.front()->arriveTime != timeCount){
                    cout << "CPU IDLE at time"  << timeCount << endl;
                    occupied = false;
                    intervalTimeLeft = 0;
                }

            }else if (intervalTimeLeft == 0){
                Process * front = startToRun;
                occupied = !readyList.empty();
                readyList.push(front);
                startToRun = readyList.front();
                readyList.pop();
                if (startToRun != nullptr){
                    occupied = true;
                }
                cout << "Process " << startToRun->ID  << " running at time" << timeCount << endl;
                intervalTimeLeft = interval;
            }else{
                if (!waitingList.empty() && waitingList.front()->arriveTime == timeCount){
                    Process * front = waitingList.front();
                    while (!waitingList.empty() && front->arriveTime == timeCount){
                        readyList.push(front);
                        waitingList.pop();
                        front = waitingList.front();
                    }

                }
                if (!readyList.empty()){
                    int readyListSize = readyList.size();
                    for (int i = 0; i < readyListSize;i++){
                        Process * front = readyList.front();
                        readyList.pop();
                        front->waitingTime++;
                        readyList.push(front);
                    }

                }
            }
            
        }