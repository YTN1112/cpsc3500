// Tony Nguyen
// sim.cpp(1)
// Purpose: This program does a simulation of process and how they
// run under 3 differnt algorhtims
// FCFS(first come first serve), SRT(Shortest time remaining)
// and RR(Round Robin)

#include <fstream>
#include <iostream>
#include <iomanip>
#include <list>
#include <queue>
#include <vector>
#include <algorithm>
#include <cstring>
#include <cmath>


using namespace std;


// This is the Process struct that is used for each process
struct Process {
    int ID;
    int arriveTime;
    int BurstTime;
    int remainingTime;
    int waitingTime;
};

// Compares arrive time to see if a swap is needed(ties broken by ID)
bool compareArriveTime(const Process* swapA, const Process* swapB);

// Compares arrive time to see if the running process needs to be swapped
// (breaks ties by ID)
bool compareRemainingTime(const Process* swapA, const Process* swapB);

// Compares waiting time to see if a swap is needed(ties broken by ID)
bool compareWaitingTime(const Process* swapA, const Process* swapB);

// This function does the first come first serve
// returns a vector of terminated processes
vector<Process*> FSFSProcess(const vector<Process*>& list, 
int &totalTime, int &totalWaitingTime);

// This function does Round robin
// returns a vector of terminated processes
vector<Process*> RRProcess(const vector<Process*>& list, int &totalTime, 
int &totalWaitingTime, int timeInterveral);


// This function does Shortest time remaining
// returns a vector of terminated processes
vector<Process*> SRTProcess(const vector<Process*>& list, 
int &totalTime, int &totalWaitingTime);





// These lines below are ERROR checking and terminating if so
int main(int argc, char *argv[]){
    if (argc != 3 && argc != 4){
        cout << "ERROR WITH COMMAND LINE." << endl;
        return 0;
    }
    if (argc == 3){
        if (strcmp(argv[2], "FCFS") != 0 && strcmp(argv[2], "SRT") != 0){
            cout << "ERROR WITH COMMAND LINE." << endl;
            return 0;
        }
    }
    if (argc == 4){
        if (strcmp(argv[2], "RR") != 0){
            cout << "ERROR WITH COMMAND LINE." << endl;
            return 0;
        }
        if (atoi(argv[3]) <= 0){
            cout << "ERROR WITH COMMAND LINE." << endl;
            return 0;
        }
    }
    ifstream file(argv[1]);  
    if (file.fail()){
        cout << "INVALID FILE!" << endl;
        return 0;
    }
    // If error checks pass, this reads the file
    string line;
    vector<Process *> processList;

    while (getline(file,line)){
    // fileread
        stringstream s = stringstream(line);
        string IDinput;
        string ArriveTimeInput;
        string BurstTimeInput;
        getline(s, IDinput, ' ');    // Read the date column
        getline(s, ArriveTimeInput, ' '); // Read the country column
        getline(s, BurstTimeInput, ' ');   // Read the cases column
        int IDint = stoi(IDinput);
        int arriveTimeInt = stoi(ArriveTimeInput);
        int BurstTimeInt = stoi(BurstTimeInput);
        Process * create = new Process();
        create->ID = IDint;
        create->arriveTime = arriveTimeInt;
        create->BurstTime = BurstTimeInt;
        create->remainingTime = create->BurstTime;
        create->waitingTime = 0;
        processList.push_back(create);

    }
    file.close();
    // This then sorts by arrivte time(ID as tiebreaker) so 
    // algrhtoims can run properly
    sort(processList.begin(), processList.end(),compareArriveTime);


    int totalTime = 0;
    int waitingTime = 0;
    vector <Process*> finalStats;
    // Based on the argument in comamand line, it will go
    // into one of these 3 algrothims
    // Terminated process vector is put into a finalStats vector
    if (strcmp(argv[2], "FCFS") == 0){
        finalStats = FSFSProcess(processList,totalTime,waitingTime);
    }
    if (strcmp(argv[2], "SRT") == 0){
        finalStats = SRTProcess(processList,totalTime,waitingTime);
    }
    if (strcmp(argv[2], "RR") == 0){
        int interval = atoi(argv[3]);
        finalStats = RRProcess(processList,totalTime,waitingTime,interval);
    }

    // Stats are displayed here
    double activeTime = totalTime-waitingTime;
    double percentActive = (activeTime/totalTime) * 100;
    int intPercentActive = static_cast<int>(round(percentActive));
    cout << endl << "CPU UTILZATION " << intPercentActive << "%" << endl;
    int waitingTimeTotal;
    for (int i = 0; i < (int)finalStats.size();i++){
        waitingTimeTotal += finalStats[i]->waitingTime;
    }
    double vectorSize = (int)finalStats.size();
    double averageWaitingTime = waitingTimeTotal/vectorSize;
    cout << fixed << setprecision(2);
    cout << "Average waiting time is: " << averageWaitingTime << endl;
    sort(finalStats.begin(),finalStats.end(),compareWaitingTime);
    int finalStatsSize = finalStats.size();
    int worstWaitingTime = finalStats[finalStatsSize-1]->waitingTime;
    cout << "Worst case waiting time is: " << worstWaitingTime << endl;

    // Dynamicaly allocated processes are CLEARED
    for (int i = 0; i < (int)processList.size(); i++){
        delete processList[i];
    }
    processList.clear();


    return 0;
}

// compares it two processes need to be swapped based on arrive time
// ID is used as tiebreaker
bool compareArriveTime(const Process* swapA, const Process* swapB) {
    if (swapA->arriveTime == swapB->arriveTime) {
        return swapA->ID < swapB->ID;
    }
    return swapA->arriveTime < swapB->arriveTime;
}

// compares it two processes need to be swapped based on remaining Time
// ID is used as tiebreaker
// This is mainly used when a new process comes in
bool compareRemainingTime(const Process* swapA, const Process* swapB) {
    if (swapA->remainingTime == swapB->remainingTime) {
        return swapA->ID < swapB->ID;
    }
    return swapA->remainingTime < swapB->remainingTime;
}

// compares it two processes need to be swapped based on waitingTime
// ID is used as tiebreaker
bool compareWaitingTime(const Process* swapA, const Process* swapB){
    if (swapA->waitingTime == swapB->waitingTime) {
        return swapA->ID < swapB->ID;
    }
    return swapA->waitingTime< swapB->waitingTime;
}

// This functtion does a First come first serve process, returns a vector
// of termianted processes
vector<Process*> FSFSProcess(const vector<Process*>& list,
int &totalTime, int &totalWaitingTime){

    queue <Process *> readyList;
    queue <Process *> waitingList;
    vector <Process *> terminatedProcesses;
    Process * startToRun;
    bool wasIdle;
    bool occupied = false;

    // Pushs all elements on list into a waitingList queue
    for (int i = 0; i < (int)list.size(); i++){
        waitingList.push(list[i]);
    }
    // These two varibles keep track of total and idle time
    int timeCount = 0;
    int idleTime = 0;
    // This loop runs as long as either theres something to be processed
    // or there is something running
    while (!readyList.empty() || !waitingList.empty() || occupied){
        if (!occupied){
            // if there is no process running currently
            if (!readyList.empty()){
                // If ready list is empty, then pulls from waiting list
                startToRun = readyList.front();
                readyList.pop();
                occupied = true;
                cout << "Process " << startToRun->ID  
                << " running at time " << timeCount << endl;
                if (!readyList.empty()){
                    while (waitingList.front() != nullptr && 
                    waitingList.front()->arriveTime == timeCount){
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push(front);
                    }
                }
            }else{
                // This exeuctes if there IS something in the ready list
                // but not occupied.
                if(waitingList.front()->arriveTime != timeCount){
                    // This happens if nothing in waitingList has arraived yet
                    idleTime++;
                    wasIdle = true;
                }else{
                    // This else runs if it is time for new process to arrive
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){

                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push(front);
                    }
                    if (!readyList.empty()){
                        // Runs the next process in time
                        startToRun = readyList.front();
                        readyList.pop();
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        occupied = true;
                    }else if(waitingList.empty() && !readyList.empty()){
                        cout << "CPU IDLE at time " << timeCount << endl;
                        idleTime++;
                    }
                    if(wasIdle){
                        // wasIdle ensures that waiting time is correct
                        idleTime++;
                        wasIdle = false;
                    }
                }
            }          
        }else{
            // Runs if occupied
            if (startToRun->remainingTime == 0){
                // This runs when a process is being terminated
                terminatedProcesses.push_back(startToRun);
                occupied = false;
                if (!readyList.empty()){
                    // if ready list has eleements, runs the next one
                    startToRun = readyList.front();
                    readyList.pop();
                    cout << "Process " << startToRun->ID  << " running at time " 
                    << timeCount << endl;
                    occupied = true;

                }if (readyList.empty() && !waitingList.empty() 
                && waitingList.front()->arriveTime == timeCount){
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){
                        // runs when ready list is empty but waiting
                        // list is ready for new processes
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push(front);
                    }
                    if (!readyList.empty()){
                        // runs next process
                        startToRun = readyList.front();
                        readyList.pop();
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        occupied = true;
                    }
                    if (wasIdle){
                        idleTime++;
                        wasIdle = false;
                    }
                }else if(readyList.empty() && !waitingList.empty() 
                && waitingList.front()->arriveTime != timeCount){

                    // Runs if process has finished but nothing ready to run
                    cout << "CPU IDLE at time "  << timeCount << endl;
                }
            }else{
                // This still checks for any processes that come into waiting list
                // even if process has not finished
                if (!waitingList.empty() 
                && waitingList.front()->arriveTime == timeCount){

                    Process * front = waitingList.front();
                    while (!waitingList.empty() 
                    && front->arriveTime == timeCount){

                        readyList.push(front);
                        waitingList.pop();
                        front = waitingList.front();
                    }

                }

            }
            
        }
        // this is done after each iteration
        startToRun->remainingTime--;
        timeCount++;
        // Counts up waitngTime for each iteration
        if (!readyList.empty()){
            int readyListSize = readyList.size();
            for (int i = 0; i < readyListSize; i++){
                Process * front = readyList.front();
                readyList.pop();
                front->waitingTime++;
                readyList.push(front);
            }        
        }
    }

    totalTime = timeCount - 1;
    totalWaitingTime = idleTime;
    return terminatedProcesses;
}




// This process does Shortest remaining time, returning a vector
vector<Process*> SRTProcess(const vector<Process*>& list,int &totalTime, 
int &totalWaitingTime){

    vector <Process *> readyList;
    queue <Process *> waitingList;
    vector <Process *> terminatedProcesses;
    Process * startToRun;
    bool wasIdle;
    bool occupied = false;
    for (int i = 0; i < (int)list.size(); i++){
        waitingList.push(list[i]);
    }
    int timeCount = 0;
    int idleTime = 0;


    while (!readyList.empty() || !waitingList.empty() || occupied){
        if (!occupied){
            // Runs if nothing is running
            if (!readyList.empty()){
                // Looks for new processes to put into ready list
                while (waitingList.front() != nullptr 
                && waitingList.front()->arriveTime == timeCount){

                    Process * front = waitingList.front();
                    waitingList.pop();
                    readyList.push_back(front);

                }
                // Sorts for the shortest remaining time
                // Then runs that process
                sort(readyList.begin(), readyList.end(),compareRemainingTime);
                startToRun = readyList.front();
                readyList.erase(readyList.begin());
                cout << "Process " << startToRun->ID  
                << " running at time " << timeCount << endl;
                occupied = true;
            }else{
                // Checks for idle time
                if(waitingList.front()->arriveTime != timeCount){
                    idleTime++;
                    wasIdle = true;
                }else{
                    // Puts any process that arraive into ready list
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){

                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push_back(front);
                    }
                    if (!readyList.empty()){
                        // Sorts list to find Shortest ready time
                        // then runs it
                        sort(readyList.begin(), readyList.end(),compareRemainingTime);
                        startToRun = readyList.front();
                        readyList.erase(readyList.begin());
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        occupied = true;
                    }else if(waitingList.empty() && !readyList.empty()){
                        cout << "CPU IDLE at time " << timeCount << endl;
                        idleTime++;
                    }
                    if(wasIdle){
                        idleTime++;
                        wasIdle = false;
                    }
                }
            }          
        }else{
            if (startToRun->remainingTime == 0){
                // Runs if terminated
                terminatedProcesses.push_back(startToRun);
                occupied = false;
                if (!readyList.empty()){
                    // process that arriave are put into ready list
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){

                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push_back(front);
                    }
                    // finds shortest time left, then runs it
                    sort(readyList.begin(), readyList.end(),compareRemainingTime);

                    startToRun = readyList.front();
                    readyList.erase(readyList.begin());
                    cout << "Process " << startToRun->ID  
                    << " running at time " << timeCount << endl;
                    occupied = true;
                }if (readyList.empty() && !waitingList.empty() 
                && waitingList.front()->arriveTime == timeCount){
                    // Runs if ready list is empty but processes arrive
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){
                        // puts into ready queue process that arrive
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push_back(front);
                    }
                    if (!readyList.empty()){
                        // finds the shortest remaining time
                        sort(readyList.begin(), readyList.end(),compareRemainingTime);
                        startToRun = readyList.front();
                        readyList.erase(readyList.begin());
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        occupied = true;
                    }
                    if (wasIdle){
                        // makes sure idle time is right
                        idleTime++;
                        wasIdle = false;
                    }
                }else if(readyList.empty() && !waitingList.empty() 
                && waitingList.front()->arriveTime != timeCount){
                    // if no process have arriaved and ready list is empty
                    // idle time is incremented.
                    cout << "CPU IDLE at time "  << timeCount << endl;
                }
            }else{
                // This else part checks when any processes arrive if occupied
                // This could lead to a process change
                if (!waitingList.empty() 
                && waitingList.front()->arriveTime == timeCount){

                    Process * front = waitingList.front();
                    // This puts any process that arrive in first
                    while (!waitingList.empty() && front->arriveTime == timeCount){
                        readyList.push_back(front);
                        waitingList.pop();
                        front = waitingList.front();
                    }
                    // Puts in order of remainingTime to check the shortest
                    sort(readyList.begin(),readyList.end(),compareRemainingTime);
                    if (!readyList.empty()){
                        Process * checkFront = readyList.front();
                        // This checks if the shortest in ready queue is less
                        // than remaining time of running
                        bool wrongOrder = 
                        compareArriveTime(startToRun,checkFront);

                        if (wrongOrder){
                            // If so, then it "preempts" by
                            // Putting the running process back
                            // into that ready list
                            // then reorders it
                            readyList.push_back(startToRun);
                            sort(readyList.begin(),readyList.end()
                            ,compareRemainingTime);

                            startToRun = checkFront;
                            // Finally, the one in front gets run
                            readyList.erase(readyList.begin());
                            cout << "Process " << startToRun->ID  
                            << " running at time " << timeCount << endl;
                        }
                    }
                }

            }
            
        }
        // Runs after each loop
        // Waiting Time in ready queue is incremented
        startToRun->remainingTime--;
        timeCount++;
        if (!readyList.empty()){
            int readyListSize = readyList.size();
            for (int i = 0; i < readyListSize; i++){
                readyList[i]->waitingTime++;
                }
            }        
    }

    totalTime = timeCount - 1;
    totalWaitingTime = idleTime;
    return terminatedProcesses;
}







vector<Process*> RRProcess(const vector<Process*>& list,int &totalTime, 
int &totalWaitingTime, int timeInterveral){

    vector <Process *> readyList;
    queue <Process *> waitingList;
    vector <Process *> terminatedProcesses;
    Process * startToRun;
    bool wasIdle;
    bool occupied = false;
    // This is so if there is only 1 process left, it wont repeat the output over and over again
    // starts at -1 because ID's start at zero.
    int lastProcessID = -1;
    for (int i = 0; i < (int)list.size(); i++){
        waitingList.push(list[i]);
    }
    int timeCount = 0;
    int idleTime = 0;
    int intervalLeft = timeInterveral;

    // This loop works a BIT differntly
    while (!readyList.empty() || !waitingList.empty() || occupied){
        if (!occupied){
            // Runs if not occupied
            if (!readyList.empty()){
                // if empty ready list, takes processes in if arrivetime
                // is the same as count
                // else idletime is incremented
                while (waitingList.front() != nullptr 
                && waitingList.front()->arriveTime == timeCount){
                    Process * front = waitingList.front();
                    waitingList.pop();
                    readyList.push_back(front);
                }
                startToRun = readyList.front();
                readyList.erase(readyList.begin());
                if (startToRun->ID != lastProcessID){
                    cout << "Process " << startToRun->ID  
                    << " running at time " << timeCount << endl;
                    lastProcessID = startToRun->ID;
                }
                occupied = true;
            }else{
                // Runs if ready queue is not empty
                // checks to see if waitingList processes
                // has arrived, if not idleTime is incremented
                if(waitingList.front()->arriveTime != timeCount){
                    idleTime++;
                    wasIdle = true;
                }else{
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push_back(front);
                    }
                    if (!readyList.empty()){
                        // Runs the next one in the queue
                        // Starts the time quantum
                        startToRun = readyList.front();
                        readyList.erase(readyList.begin());
                    if (startToRun->ID != lastProcessID){
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        lastProcessID = startToRun->ID;
                    }
                        occupied = true;
                        intervalLeft = timeInterveral;
                    }else if(waitingList.empty() && !readyList.empty()){
                        cout << "CPU IDLE at time " << timeCount << endl;
                        idleTime++;
                    }
                    if(wasIdle){
                        idleTime++;
                        wasIdle = false;
                    }
                }
            }          
        }else{
            // Runs if occupied
            if (startToRun->remainingTime == 0){
                // This runs if process terminates
                terminatedProcesses.push_back(startToRun);
                occupied = false;
                if (!readyList.empty()){
                    // Both of these loops regardless of readylist status
                    // in order to check for waitinglist processes
                    //that arrive
                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){

                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push_back(front);
                    }
                    // Runs the next process to be run after a termination
                    // starts time quantum interval
                    startToRun = readyList.front();
                    readyList.erase(readyList.begin());
                    if (startToRun->ID != lastProcessID){
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        lastProcessID = startToRun->ID;
                    }
                    occupied = true;
                    intervalLeft = timeInterveral;
                }if (readyList.empty() && !waitingList.empty() 
                && waitingList.front()->arriveTime == timeCount){
                    // If ready list is empty but process
                    // has arrived, puts into ready list
                    // otherwise idletime is incremented

                    while (waitingList.front() != nullptr 
                    && waitingList.front()->arriveTime == timeCount){
                        Process * front = waitingList.front();
                        waitingList.pop();
                        readyList.push_back(front);
                    }
                    if (!readyList.empty()){
                        // Runs next process, resets interval
                        startToRun = readyList.front();
                        readyList.erase(readyList.begin());

                    if (startToRun->ID != lastProcessID){
                        cout << "Process " << startToRun->ID  
                        << " running at time " << timeCount << endl;
                        lastProcessID = startToRun->ID;
                    }
                        occupied = true;
                        intervalLeft = timeInterveral;
                    }
                    if (wasIdle){
                        idleTime++;
                        wasIdle = false;
                    }
                    
                }else if(readyList.empty() && !waitingList.empty() 
                && waitingList.front()->arriveTime != timeCount){
                    cout << "CPU IDLE at time "  << timeCount << endl;
                }

            }else if(intervalLeft == 0){
                // This runs if interval has run its course
                // BUT it has not terminated
                // The process that just run is put
                // back into queue FIRST
                readyList.push_back(startToRun);
                Process * waitingListFront = waitingList.front();
                while (!waitingList.empty() 
                && waitingListFront->arriveTime == timeCount){
                    // Then new processes that arrive are put alter
                    readyList.push_back(waitingListFront);
                    waitingList.pop();
                    waitingListFront = waitingList.front();
                }
                // Starts new process in front and the interval
                startToRun = readyList.front();
                readyList.erase(readyList.begin());

                if (startToRun->ID != lastProcessID){
                    cout << "Process " << startToRun->ID  
                    << " running at time " << timeCount << endl;
                    lastProcessID = startToRun->ID;
                }

                intervalLeft = timeInterveral;
                occupied = true;
            }else{
                // Runs if neither interval time has run out
                // or a termination happens
                // It simply checks for any process has arrived
                // and gets put into ready queue if swo
                if (!waitingList.empty() 
                && waitingList.front()->arriveTime == timeCount){
                    Process * front = waitingList.front();
                    while (!waitingList.empty() 
                    && front->arriveTime == timeCount){
                        readyList.push_back(front);
                        waitingList.pop();
                        front = waitingList.front();
                    }
                }

            }
            
        }
        // Runs after each loop
        // time is tracked
        // and so is the interval left
        startToRun->remainingTime--;
        if (intervalLeft != 0){
            intervalLeft--;
        }
        timeCount++;
        if (!readyList.empty()){
            int readyListSize = readyList.size();
            for (int i = 0; i < readyListSize; i++){
                readyList[i]->waitingTime++;
            }
        }        
    }

    totalTime = timeCount - 1;
    totalWaitingTime = idleTime;
    return terminatedProcesses;
}

// Note, make sure if it has already gone before, it doesen't print again. It should only print once.
// In the sample file, RR process 4 should only print once its down to the final one.