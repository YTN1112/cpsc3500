#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include "Command.h"
using namespace std;
int main()
{
    cout << "Hello World" << endl;
    cout << "ME!" << endl;
    return 0;
}