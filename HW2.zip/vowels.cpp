// vowels.cpp: multithreaded vowel count

#include <iostream>
// Tony Nguyen
// vowels.cpp

#include <fstream>
#include <string>
#include <cstdlib>
#include <pthread.h>
using namespace std;

#define NUM_THREADS 20
// struct for vowelCount, along with ID so it reads
// a seperate file each time
struct vowelCount{
  int aCount = 0;
  int eCount = 0;
  int iCount = 0;
  int oCount = 0;
  int uCount = 0;
  int ID;
};
// Worker thread function to return the number
// of vowels
// must pass in a void* and return a void*
// as well
// void* is like a wildcard
void* worker(void *arg);


int main()
{
  pthread_t threads[NUM_THREADS];
  struct vowelCount* structArray[20];
  // This loop creates threads 20 times
  // stored in a struct array of pointers
  for (int i = 0; i < NUM_THREADS; i++){
    int* index = new int;  // Dynamically allocate the index value
    *index = i; // This is critical to prevent context switch mess
    structArray[*index] = new vowelCount; // also creates a new instance
    structArray[*index]->ID = *index + 1;
    if (pthread_create(&threads[i], nullptr, 
    worker, static_cast<void*>(structArray[*index])) != 0) {
      // This create it will its index sent to the function
      cout << "Error creating thread " << *index 
      << ". Exiting program." << endl;
      exit(EXIT_FAILURE);
    }
    delete index;
  }
    
  struct vowelCount finalCount;

  for (int i = 0; i < NUM_THREADS; i++){
    // This joins all threads together
    // and gets the final count
    pthread_join(threads[i],nullptr);
    finalCount.aCount += structArray[i]->aCount;
    finalCount.eCount += structArray[i]->eCount;
    finalCount.iCount += structArray[i]->iCount;
    finalCount.oCount += structArray[i]->oCount;
    finalCount.uCount += structArray[i]->uCount;
    delete structArray[i];
  }
  cout << "A: " << finalCount.aCount << endl;
  cout << "E: " << finalCount.eCount << endl;
  cout << "I: " << finalCount.iCount << endl;
  cout << "O: " << finalCount.oCount << endl;
  cout << "U: " << finalCount.uCount << endl;


  return 0;
}


void* worker(void *arg){
  // void is like a wild card pointer, so I have to
  // cast the arugment back to a vowelcount before
  // continung
  // each instance gets a differnt id
  vowelCount* workerProcess = static_cast<vowelCount*>(arg);
  int indexFile = workerProcess->ID;
  // parsing file string together before opening it
  string base = "file";
  string result = base + to_string(indexFile) + ".txt";
  string directory = "/home/fac/elarson/cpsc3500/files/";
  string fileDirectory = directory + result;
  ifstream file(fileDirectory);
  if (file.fail()){
    cout << "ERROR OPENING FILE!" << endl;
    return nullptr;
  }
  string line;
  while (getline(file,line)){
    // Reads every line to the end for 
    // upper or lower case vowels
    int lineLength = line.length();
    for (int i = 0; i < lineLength; i++){
      if (line[i] == 'A' || line[i] == 'a'){
        workerProcess->aCount++;
      }
      if (line[i] == 'E' || line[i] == 'e'){
        workerProcess->eCount++;
      }
      if (line[i] == 'I' || line[i] == 'i'){
        workerProcess->iCount++;
      }
      if (line[i] == 'O' || line[i] == 'o'){
        workerProcess->oCount++;
      }
      if (line[i] == 'U' || line[i] == 'u'){
        workerProcess->uCount++;
      }
    }
  }


  file.close();
  // Since this returns a void*, I must static cast it
  return static_cast<void*>(workerProcess);

}