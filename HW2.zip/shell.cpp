#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <cstring>
#include "Command.h"
using namespace std;
//pwd or ls
// remember to do the child directory case where it just has a child directory no slashes
// to test for invalid permissions, scratch is no premisison
// ex cd cpsc3500 is the case your missing

const int PATH_MAX = 4096;

int main(int argc, char* argv[]) {
    Command command;
    string commandString = " ";
    char buffer[PATH_MAX];
    // buffer is to get current directory

    cout << "Please enter command" << endl;
    getline(cin, commandString);
    command.parseCommandString(commandString);
    // Command line is parased

    while (commandString != "quit") {
        // There are two main paths, CD and not
        if (command.getArg(0) == "cd") {
            // if first part is cd, checks for
            // at MOST 2 arugments
            if (command.getNumArgs() > 2){
                cout << "INVALID COMMAND LINE" << endl;
            }else{
                if (command.getArg(1) == "."){
                    // This shows the current directory
                    if (getcwd(buffer, sizeof(buffer)) != nullptr) {
                        string currentDirectory = buffer;
                        cout << "Current working directory: " 
                        << currentDirectory << endl;
                    }else{
                        perror("getcwd() error");
                    }
                }else if (command.getArg(1) == ".."){
                    if ((getcwd(buffer, sizeof(buffer)) == nullptr)){
                        perror("getcwd() error");
                    }
                    // string is grabbed from the buffer
                    string currentDirectory = buffer;
                    int slashCounter = 0;
                    // This counts how many / are there in current directory
                    for (int i = 0; i < currentDirectory.length() ; i++){
                        if (currentDirectory[i] == '/'){
                            slashCounter++;
                        }
                    }
                    int stringCount = 0;
                    int slashCount2 = 0;
                    string parent;
                    while (stringCount != currentDirectory.length() 
                    && slashCount2 != slashCounter){
                        // It looks for the final slash

                        if (currentDirectory[stringCount] == '/'){
                            slashCount2++;
                        }
                        stringCount++;
                    }
                    // substr goes from 0 to the last charcter before
                    // the last slash
                    parent = currentDirectory.substr(0,stringCount - 1);
                    if (chdir(parent.c_str()) == 0) {
                        cout << "Changed to  " << parent <<  endl;
                    }else{
                            perror("chdir() error");
                    }

                
                }else if(command.getNumArgs() == 1){
                    // This is if cd is entered by itself
                    string homeDirectory = getenv("HOME");
                    if (chdir(homeDirectory.c_str()) == 0){
                        cout << "Changed to " << homeDirectory << endl;
                    }else{
                        perror("chdir() error");
                    }
                }else{
                    // this is either a path or realtive path is sent
                    string sendString = command.getArg(1);
                    int slashCount = 0;
                    for (int i = 0; i < sendString.size(); i++){
                        if (sendString[i] == '/'){
                            slashCount++;
                        }
                    }
                    if (slashCount == 0){
                        // if its not a path, then looks for current path
                        // then adds user input to that path
                        if (getcwd(buffer, sizeof(buffer)) != nullptr) {
                            string currentDirectory = buffer;
                            currentDirectory += '/';
                            currentDirectory += sendString;
                            sendString =  currentDirectory;
                        }else{
                            perror("getcwd() error");
                        }     
                    }
                    if (chdir(sendString.c_str()) == 0){
                        cout << "Changed to " << sendString << endl;
                    }else{
                        perror("chdir() error");
                    }


                }
            }
        }else{
            //Otherwise runs a program, forks the program
            pid_t child_pid = fork();
            //error checking
            if (child_pid == -1) {
                perror("Fork");
                exit(EXIT_FAILURE);
            } else if (child_pid == 0) {
                // if child, getArgList gets what to run
                char** args = command.getArgList();
                int count = 0; 
                // checks for sucessful run or not                 
                if (execvp(args[0], args) == -1) {
                    perror("execvp");
                    exit(EXIT_FAILURE);
                }

                    // This part will not be reached if execvp is successful
                    cout << "ERROR, execvp did something weird" << endl;
                } else {
                    // if parent, it just waits
                    wait(NULL);
                }
        
        }
        // ask again until quit is put in
        //  if user puts quit now
        // execvp error will show

        cout << "Please enter command" << endl;
        getline(cin, commandString);
        command.parseCommandString(commandString);
    }

    return 0;
}

