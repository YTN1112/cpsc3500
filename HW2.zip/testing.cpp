#include <iostream>
#include <string>
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include "Command.h"
using namespace std;

int main(int argc, char* argv[]) {
    Command command;
    string commandString = " ";

    cout << "Please enter command" << endl;
    getline(cin, commandString);
    command.parseCommandString(commandString);

    while (commandString != "quit") {
        if (command.getArg(0) == "cd") {
            cout << "CD" << endl;
        } else {
            pid_t child_pid = fork();

            if (child_pid == -1) {
                perror("Fork");
                exit(EXIT_FAILURE);
            } else if (child_pid == 0) {
                // Child process
                char** args = command.getArgList();

                // Open a file for redirecting output
                int output_fd = open("output.txt", O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
                if (output_fd == -1) {
                    perror("open");
                    exit(EXIT_FAILURE);
                }

                // Redirect stdout to the file
                dup2(output_fd, STDOUT_FILENO);
                close(output_fd);

                if (execvp(args[0], args) == -1) {
                    perror("execvp");
                    exit(EXIT_FAILURE);
                }
            } else {
                // Parent process
                cout << "Waiting on child" << endl;
                waitpid(child_pid, nullptr, 0);
                cout << "CHILD COMPLETE" << endl;
            }
        }

        cout << "Please enter command" << endl;
        getline(cin, commandString);
        command.parseCommandString(commandString);
    }

    return 0;
}
// fork returns TWICE(parent, child)
// child process calls exec system to call program
// parrent will just wait

// cd: Check for CD command
// look at linux system calls handout

// directory maniuplation(find one of those to use)
// introduct to linux calls handout in unit 1
// figure out the exect part FIRST for running a file/fork


// Then do quit and cd
// if you not in main, call EXIT
// There is an include file that you will need to call