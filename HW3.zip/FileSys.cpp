// CPSC 3500: File System
// Implements the file system commands that are available to the shell.
// Tony Nguyen
// PA3.cpp

#include <cstring>
#include <iostream>
using namespace std;

#include "FileSys.h"
#include "BasicFileSys.h"
#include "Blocks.h"

// mounts the file system
void FileSys::mount() {
  bfs.mount();
  curr_dir = 1;
}

// unmounts the file system
void FileSys::unmount() {
  bfs.unmount();
}

// make a directory
void FileSys::mkdir(const char *name)
{
  dirblock_t homeDirBlock;
  bfs.read_block(1, &homeDirBlock);
  // checks to make sure that num entires is not more than 10
  if (homeDirBlock.num_entries > MAX_DIR_ENTRIES){
    cerr << "Error: Home directory is full" << endl;
    return;
  }
  string nameString(name);
  // chekcs to make sure file name size is not too long
  if (nameString.size() > MAX_FNAME_SIZE){
    cerr << "File name TOO LONG" << endl;
    return;
  }
  int empty_entry_index = -1;
  int index = 0;
  // find the file name, if a file or directory with that name already exists
  // and its block num is NOT 0, then it returns an error
  // otherwise if it find a block with num 0, then creates the directory
  while (index < MAX_DIR_ENTRIES && empty_entry_index == -1) {
    if (homeDirBlock.dir_entries[index].name == nameString
    && homeDirBlock.dir_entries[index].block_num != 0){
      cerr << "Directory/File with " 
      << nameString << " already exists. Cannot create" << endl;
      return;
    }
    if (homeDirBlock.dir_entries[index].block_num == 0) {
        empty_entry_index = index;
        cout << empty_entry_index << endl;
    }
    index++;
  }
    if (empty_entry_index == -1) {
        cerr << "Error: Failed to find an empty entry in the home directory" 
        << endl;
        return;
    }
  
  // gets free block, returns error if it can't find one
  int newBlock = bfs.get_free_block();
  cout << newBlock << endl;
  if (newBlock == 0){
    cerr << "Error, no free blocks aviaible for directory creation" << endl;
    return;
  }
  // creates the new entry
  dirblock_t newDirEntry;
  newDirEntry.magic = DIR_MAGIC_NUM;
  newDirEntry.num_entries = 0;
  int newEntryIndex = homeDirBlock.num_entries;
  // assings the index and increases entires by 1
  homeDirBlock.num_entries++;
  cout << "newEntryIndex is :" << newEntryIndex << endl;
  strcpy(homeDirBlock.dir_entries[newEntryIndex].name,name);
  homeDirBlock.dir_entries[newEntryIndex].block_num = newBlock;
  // writes back to disk
  bfs.write_block(1, &homeDirBlock);
  bfs.write_block(newBlock, &newDirEntry); // and here
  cout << "Directory '" << name << "' created at block " << newBlock << endl;
}

// switch to a directory

void FileSys::cd(const char *name){
  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  //checks for directory then switches once found
  // if not found, returns directory not found
  // if name is a FILE, then returns not a directory
  // error
  for (int i = 0; i < curDirBlock.num_entries; i++) {
  if (strcmp(curDirBlock.dir_entries[i].name, name) == 0){
    if (curDirBlock.dir_entries[i].block_num != 0 && 
    isDir(curDirBlock.dir_entries[i].block_num, curDirBlock)){

      curr_dir = curDirBlock.dir_entries[i].block_num;
      break;
    }else{
      cerr << name << " is not a directory" << endl;\
      return;
    }

  }else{
    cerr << "Directory not found for " << name << endl;
    return;  
    }
  }
}

// switch to home directory
void FileSys::home() {
  struct dirblock_t dirblock;
  bfs.read_block(1, (void *) &dirblock);
  curr_dir = 1;
}

// remove a directory
void FileSys::rmdir(const char *name)
{
  // loads current directory
  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  int removeSubDirBlock = -1;
  int removeIndex = -1;
  // looks for name, if a file it reuurns an error
  // also checks for block num not equal to 0
  for (int i = 0; i < curDirBlock.num_entries; i++) {
  if (strcmp(curDirBlock.dir_entries[i].name, name) == 0){
    if (curDirBlock.dir_entries[i].block_num != 0 && isDir(curDirBlock.dir_entries[i].block_num, curDirBlock)){
      removeSubDirBlock = curDirBlock.dir_entries[i].block_num;
      removeIndex = i;
      break;
    }else{
      cerr << name << " is not a directory" << endl;
      return;
    }

    }
  }
  // returns an error if name can't be found
  if (removeSubDirBlock == -1){
    cerr << "ERROR: Subdirectory not found" << endl;
    return;
  }
  // loads the directory to be deleted, checks
  // to make sure its empty, if not returns an error
  dirblock_t removeSubdirBlock;
  bfs.read_block(removeSubDirBlock, &removeSubdirBlock);
  if (removeSubdirBlock.num_entries > 0){
    cerr << "Subdirectory NOT empty, cannot remove" << endl;
    return;
  }
  // swap the last entry with the entry to be deleted
  // auto is used so it is auto assigned the right varibile
  if (removeIndex != curDirBlock.num_entries - 1){
    auto temp = curDirBlock.dir_entries[removeIndex];
    curDirBlock.dir_entries[removeIndex] = curDirBlock.dir_entries[curDirBlock.num_entries - 1];
    curDirBlock.dir_entries[curDirBlock.num_entries - 1] = temp;
  }
  // directory is reclaimed, block num is set to 0, then write to the block
  bfs.reclaim_block(curDirBlock.dir_entries[curDirBlock.num_entries - 1].block_num);
  curDirBlock.dir_entries[curDirBlock.num_entries - 1].block_num = 0;
  curDirBlock.num_entries--;
  bfs.write_block(curr_dir, &curDirBlock);

  
}

// list the contents of current directory
void FileSys::ls()
{
  // lists what is in the currenty directory
  // if it is a directory, it list / next to it
  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  cout << "curDirBlock.num_entries: " << curDirBlock.num_entries << endl;
  for (int i = 0; i < curDirBlock.num_entries; i++){
    cout << curDirBlock.dir_entries[i].name;
    if (isDir(curDirBlock.dir_entries[i].block_num, curDirBlock)){
      cout << "/";
    }
    cout << endl;
  }

}

// create an empty data file
void FileSys::create(const char *name)
{
  // loads directory, checks to ensure there are spots
  // to put the entry in
  dirblock_t homeDirBlock;
  bfs.read_block(1, &homeDirBlock);
  if (homeDirBlock.num_entries > MAX_DIR_ENTRIES){
    cerr << "Error: Home directory is full" << endl;
    return;
  }
  int empty_entry_index = -1;
  int index = 0;
  string nameString(name);
  if (nameString.size() > MAX_FNAME_SIZE){
    cerr << "File name TOO LONG" << endl;
    return;
  }
  // This looks for a free index
  // returns an error if the name matches to a directory
  // while loop goes until it reaches MAX_DIR_ENTIRES
  // or a empty index is found
  while (index < MAX_DIR_ENTRIES && empty_entry_index == -1) {
    if (homeDirBlock.dir_entries[index].name == nameString 
    && homeDirBlock.dir_entries[index].block_num != 0){
      cerr << "File/Directory with " << nameString << " already exists. Cannot create" << endl;
      return;
    }
    if (homeDirBlock.dir_entries[index].block_num == 0) {
        empty_entry_index = index;}
    index++;
  }
  // If it cannot find a empty entry, it returns an error
    if (empty_entry_index == -1) {
        cerr << "Error: Failed to find an empty entry in the home directory" << endl;
        return;
    }
  
  // gets new block for I node
  int newBlock = bfs.get_free_block();
  if (newBlock == 0){
    cerr << "Error, no free blocks aviaible for directory creation" << endl;
    return;
  }
  inode_t newEntry;
  newEntry.magic = INODE_MAGIC_NUM;
  newEntry.size = 0;
  int newEntryIndex = homeDirBlock.num_entries;
  homeDirBlock.num_entries++;
  // I node is created and put into table
  cout << "newEntryIndex is :" << newEntryIndex << endl;
  strcpy(homeDirBlock.dir_entries[newEntryIndex].name,name);
  // copies name into the index of homedirblock
  homeDirBlock.dir_entries[newEntryIndex].block_num = newBlock;
  bfs.write_block(1, &homeDirBlock);
  bfs.write_block(newBlock, &newEntry); // and here
  cout << "File'" << name << "' created at block " << newBlock << endl;
}

// append data to a data file
void FileSys::append(const char *name, const char *data)
{
  // first finds string length
  size_t length = strlen(data);
  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  int fileBlockIndex;
  bool found = false;
  // chekcs to find the block, if its a directory, returns an error
  for (int i = 0; i < curDirBlock.num_entries; i++) {
  if (strcmp(curDirBlock.dir_entries[i].name, name) == 0){
    if (curDirBlock.dir_entries[i].block_num != 0 && 
    isDir(curDirBlock.dir_entries[i].block_num, curDirBlock) == false){
      fileBlockIndex = curDirBlock.dir_entries[i].block_num;      
      found = true;
      break;
    }else{
      cerr << name << " is not a file" << endl;
      return;
    }

    }
  }
  if (!found){
    cerr << "file not found for " << name << endl;
    return;
  }
  // if I node found, the I node is loaded
  inode_t readingINode;
  bfs.read_block(fileBlockIndex, &readingINode);
  // the current blockIndex, offset, and remainingspaceinblock
  // is calcualted, these are imporant
  int blockIndex = readingINode.size / BLOCK_SIZE;
  int offset = readingINode.size % BLOCK_SIZE;
  int remainingSpaceInBlock = BLOCK_SIZE - offset;
  // first error check to make sure its larger than file size
  if (length >= MAX_FILE_SIZE){
    cerr << "DATA IS TOO LARGE. Append exceeds maximum file size " << endl;
    return;
  }
  // This second error check is in case the file is NOT empty
  // it calcualtes the remaning space left, and returns an error
  // if there is not enough room
  if (length > MAX_FILE_SIZE-((blockIndex * BLOCK_SIZE)+remainingSpaceInBlock)){
    cerr << "Not enough space on the disk. Append exceeds maximum file size" << endl;
    return;
  }
  // this for loop appends 1 char at a time    
  for (int i = 0; i < length; i++){
    // if the offset is zero, we need a new block
    if (offset == 0){
      int newBlock = bfs.get_free_block();        
      if (newBlock == 0){
        cerr << "NO BLOCKS AVIAIBLE" << endl;
        return;
      }
    // new block in the I node
    readingINode.blocks[blockIndex] = newBlock;

    }
    // datablock is loaded in and a char is added
    datablock_t dataBlockRead;
    bfs.read_block(readingINode.blocks[blockIndex], &dataBlockRead);
    dataBlockRead.data[offset] = data[i];
    bfs.write_block(readingINode.blocks[blockIndex], &dataBlockRead);
    offset++;
    readingINode.size++;
    remainingSpaceInBlock--;
    // this is when the block becomes full, it will set offset to zero
    // so the next iteration it will create a new block
    // BEFORE it contiunes appending
    // blockindex is also updated
    if (offset == BLOCK_SIZE) {
      offset = 0;
      blockIndex++;
    }    


    }
  bfs.write_block(fileBlockIndex, &readingINode); 

}

// display the contents of a data file
void FileSys::cat(const char *name)
{
  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  int fileBlockIndex;
  bool found = false;
  // looks for the directory entry, will return an error
  // if a directory that matches the name
  for (int i = 0; i < curDirBlock.num_entries; i++) {
  if (strcmp(curDirBlock.dir_entries[i].name, name) == 0){
    if (curDirBlock.dir_entries[i].block_num != 0 && 
    isDir(curDirBlock.dir_entries[i].block_num, curDirBlock) == false){
      fileBlockIndex = curDirBlock.dir_entries[i].block_num;
      found = true;
      break;
    }else{
      cerr << name << " is not a file" << endl;
      return;
    }

    }
  }
  if (!found){
    cerr << "file not found for " << name << endl;
    return;
  }
    inode_t readingINode;
    bfs.read_block(fileBlockIndex, &readingINode);

    int blockIndex = readingINode.size / BLOCK_SIZE;
    int offset = readingINode.size % BLOCK_SIZE;
    // if empty, it dispalys this message
    if (blockIndex == 0 && offset == 0){
      cout << "The file is empty....." << endl;
      return;
    }
    // If offset is 0, but block Index is NOT zero
    // then blockindex is decremented by 1 to prevent out of bounds
    // and offset is set to BLOCK_SIZE to indicate a full block
    if (blockIndex != 0 && offset == 0){
      blockIndex = blockIndex - 1;
      offset = BLOCK_SIZE;
    }

    for (int i = 0; i <= blockIndex; i++) { // Iterate over all blocks, including the last one
      datablock_t dataBlockRead;
      bfs.read_block(readingINode.blocks[i], &dataBlockRead);
      int end = BLOCK_SIZE;
      // if not at final block, it will set end to the end of the block
      if (i == blockIndex) {
        end = offset; // Adjust end for the last block
        // for a offset of zero, it will just not print anything
      }
      for (int j = 0; j < end; j++) {
        cout << dataBlockRead.data[j];
      }
    }

    cout << endl;

}

// delete a data file
void FileSys::rm(const char *name)
{
  // reclaim all blocks used in the file(like all the data blocks)
  // re claim the i node
  // you dont need to 0 them out
  // finally, remove entry from current directory, like remove dir
  // remove i node AND data blocks
  // order for data blocks does not matter
  // like cat, you remove them
  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  int removeSubINode = -1;
  int removeIndex = -1;
  for (int i = 0; i < curDirBlock.num_entries; i++) {
  if (strcmp(curDirBlock.dir_entries[i].name, name) == 0){
    if (curDirBlock.dir_entries[i].block_num != 0 && !isDir(curDirBlock.dir_entries[i].block_num, curDirBlock)){
      removeSubINode = curDirBlock.dir_entries[i].block_num;
      removeIndex = i;
      break;
    }else{
      cerr << name << " is a directory, cannot remove using rm" << endl;
      return;
    }

    }
  }
  if (removeSubINode == -1){
    cerr << "ERROR: File not found" << endl;
    return;
  }
  // loads in I node to be removed
  inode_t removeInode;
  bfs.read_block(removeSubINode, &removeInode);
  int blockIndex = removeInode.size / BLOCK_SIZE;
  int offset = removeInode.size % BLOCK_SIZE;
  // each data block is read in, and then reclaimed
  // and written back to the disk
  // If offset is 0, but block Index is NOT zero
  // then blockindex is decremented by 1 to prevent out of bounds
  if (offset == 0 && blockIndex != 0){
    blockIndex = blockIndex - 1;
  }
  if (blockIndex != 0 || offset != 0){
    for (int i = 0; i <= blockIndex; i++) { // Iterate over all blocks, including the last one
      datablock_t dataBlockRead;
      bfs.read_block(removeInode.blocks[i], &dataBlockRead);
      bfs.reclaim_block(removeInode.blocks[i]);
      bfs.write_block(removeInode.blocks[i], &dataBlockRead);
    }
  }
  // Inode size is set to zero, then Inode gets reclaimed
  removeInode.size = 0;
  bfs.reclaim_block(removeSubINode);
  // swaps the last entry with the file to be removed in directory
  // temp var is used to safe copy
  if (removeIndex != curDirBlock.num_entries - 1){
    auto temp = curDirBlock.dir_entries[removeIndex];
    curDirBlock.dir_entries[removeIndex] = curDirBlock.dir_entries[curDirBlock.num_entries - 1];
    curDirBlock.dir_entries[curDirBlock.num_entries - 1] = temp;
  }
  // the entry to be deleted is relciamed and that block num
  // is set to zero so it be marked unused
  bfs.reclaim_block(curDirBlock.dir_entries[curDirBlock.num_entries - 1].block_num);
  curDirBlock.dir_entries[curDirBlock.num_entries - 1].block_num = 0;
  curDirBlock.num_entries--;
  bfs.write_block(curr_dir, &curDirBlock);

  
}

// display stats about file or directory
void FileSys::stat(const char *name)
{

  dirblock_t curDirBlock;
  bfs.read_block(curr_dir, &curDirBlock);
  int fileBlockIndex;
  bool found = false;
  // This checks for either a file or directory
  // and does differnt things depedning on the result
  for (int i = 0; i < curDirBlock.num_entries; i++) {
  if (strcmp(curDirBlock.dir_entries[i].name, name) == 0){
    if (curDirBlock.dir_entries[i].block_num != 0 && 
    isDir(curDirBlock.dir_entries[i].block_num, curDirBlock) == false){
      // if its a file, it reads in the Inode for further
      // infomation
      fileBlockIndex = curDirBlock.dir_entries[i].block_num;
      found = true;
      inode_t readingINode;
      bfs.read_block(fileBlockIndex, &readingINode);
      cout << "Inode block: " << curDirBlock.dir_entries[i].block_num << endl;
      cout << "Bytes in file: " << readingINode.size << endl;
      // This if checks if the Inode is empty or not
      // if so, prints 1
      // else prints the # of blocks + 2 UNLESS
      // the block is full, then it only prints blocks + 1
      if (readingINode.size == 0){
        cout << "Number of Blocks: " << 1 << endl;
      }else{
        if (readingINode.size % BLOCK_SIZE == 0){
          cout << "Number of Blocks: " << (int(readingINode.size/BLOCK_SIZE))+1 << endl;
        }else{
          cout << "Number of Blocks: " << (int(readingINode.size/BLOCK_SIZE))+2 << endl;
        }
        

      }      
      break;
    }else{
      cout << "Directory block: " << curDirBlock.dir_entries[i].block_num << endl;
      found = true;
    }

    }
  }
  if (!found){
    cerr << "file not found for " << name << endl;
    return;
  }
}


bool FileSys::isDir(const int blockNum, dirblock_t &directoryBlock){
  // checks for isDir using the magic number
  dirblock_t newDirBlock;
  bfs.read_block(blockNum, &newDirBlock);
  return (newDirBlock.magic == DIR_MAGIC_NUM);
}
